//src/Components/Footer.js

//imports
import React from 'react';

export default function Footer() {
    return(
        <footer>
            <h3>Footer</h3>
        </footer>
    );
}